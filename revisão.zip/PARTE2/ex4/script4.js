var imagem = document.getElementById("minhaImagem");
 
    imagem.addEventListener("mouseover", function() {
        alert("Barbie");
    });