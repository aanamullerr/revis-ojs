var campoTexto = document.getElementById("campoTexto");
    var botaoValidar = document.getElementById("botaoValidar");
 
    botaoValidar.addEventListener("click", function() {
        if (campoTexto.value.trim() === "") {
            campoTexto.style.borderColor = "red";
        } else {
            campoTexto.style.borderColor = ""; 
        }
    });

