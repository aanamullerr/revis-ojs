var botao = document.getElementById("meuBotao");

botao.addEventListener("click", function() {
    alert("Você clicou no botão!");
});