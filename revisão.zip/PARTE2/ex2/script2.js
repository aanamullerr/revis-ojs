const input = document.getElementById("text")

input.addEventListener("keypress", (e) => {
    alert("Oi Mundo!")
})
