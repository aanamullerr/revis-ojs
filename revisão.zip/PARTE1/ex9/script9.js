function removerPontuacao(input) {
    var cpf = input.value.replace(/\D/g, '');

    input.nextElementSibling.value = cpf;
}


