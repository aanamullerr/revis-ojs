var botao = document.getElementById("botao");

botao.addEventListener("click", function(){
    var nomeInput = document.getElementById("nome");
    var nome = nomeInput.value.trim();

    if (nome !== "") {
        alert("O NOME COMPLETO É: " + nome);
        var quantletras = nome.length;
        alert("QUANTIDADE DE LETRAS: " + quantletras);
    } else {
        alert("INSIRA ALGO");
    }
});