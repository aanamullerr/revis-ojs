function alterarCor(cor) {
    var conteudo = document.getElementById('conteudo');
    if (cor === 'verde') {
      conteudo.style.backgroundColor = 'green';
    } else if (cor === 'vermelho') {
      conteudo.style.backgroundColor = 'red';
}}