
document.getElementById("lampada").addEventListener("click", function(){
    let img = document.getElementById("lampada");

    if (img.src.match("apagada.jpeg")) {
        img.src = "acessa.jpeg";
    } else {
        img.src = "apagada.jpeg";
    }
})