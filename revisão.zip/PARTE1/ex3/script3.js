const num1 = 13;
const num2 = 3;

alert(num1 + num2)

